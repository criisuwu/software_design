var searchData=
[
  ['id_0',['id',['../classRobot.html#ad7fd8fd1721ae41eb67246b9b360e7a6',1,'Robot::id'],['../classUser.html#aa7e6e39b43020bbe9c3a196b3689b0f7',1,'User::id']]],
  ['initializerobots_1',['initializeRobots',['../classSistema.html#ae73f607f7499295c3d838f0804298058',1,'Sistema']]],
  ['instance_2',['instance',['../classSistema.html#ac2d77d45c73ac63c7f8120264965c8c8',1,'Sistema']]],
  ['invalidcredentialserror_3',['invalidcredentialserror',['../classInvalidCredentialsError.html',1,'InvalidCredentialsError'],['../classInvalidCredentialsError.html#af0bbdad59bff8a05cc59447a3edf2691',1,'InvalidCredentialsError::InvalidCredentialsError()']]],
  ['isactive_4',['isActive',['../classRobot.html#aa9aee5aa79a6ba634935156c7238a7d8',1,'Robot']]]
];
