var searchData=
[
  ['robots_0',['robots',['../classSistema.html#a1954be491a70ce4aae67f05185d9ece0',1,'Sistema']]],
  ['role_1',['role',['../classUser.html#ac066a219bd8d28680aefb90ecc8fc635',1,'User']]]
];
