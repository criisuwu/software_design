var searchData=
[
  ['name_0',['name',['../classUser.html#a085d8d69282b6298964eab8351584536',1,'User']]],
  ['notifyappointment_1',['notifyAppointment',['../classRobot.html#a1326c0dc16d31ef4f9f9493fac1765fc',1,'Robot']]]
];
