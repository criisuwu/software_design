var searchData=
[
  ['initializerobots_0',['initializeRobots',['../classSistema.html#ae73f607f7499295c3d838f0804298058',1,'Sistema']]],
  ['invalidcredentialserror_1',['InvalidCredentialsError',['../classInvalidCredentialsError.html#af0bbdad59bff8a05cc59447a3edf2691',1,'InvalidCredentialsError']]],
  ['isactive_2',['isActive',['../classRobot.html#aa9aee5aa79a6ba634935156c7238a7d8',1,'Robot']]]
];
