var searchData=
[
  ['registernewuser_0',['registerNewUser',['../main_8cpp.html#a772fb6161ca7b62e307249661c3806a9',1,'main.cpp']]],
  ['registeruser_1',['registerUser',['../classSistema.html#a9366045d0285940588214d310432f02c',1,'Sistema']]],
  ['requestappointment_2',['requestAppointment',['../classPatient.html#a82fa1f20987f1da67ee32a267b3e9c59',1,'Patient']]],
  ['robot_3',['Robot',['../classRobot.html#af1d62a40994cf7ea2cfbf5220b079aa2',1,'Robot']]],
  ['robotmanagementmenu_4',['robotManagementMenu',['../main_8cpp.html#ad448663e45a2e200260f02b5b7a24a2a',1,'main.cpp']]]
];
