var searchData=
[
  ['registernewuser_0',['registerNewUser',['../main_8cpp.html#a772fb6161ca7b62e307249661c3806a9',1,'main.cpp']]],
  ['registeruser_1',['registerUser',['../classSistema.html#a9366045d0285940588214d310432f02c',1,'Sistema']]],
  ['requestappointment_2',['requestAppointment',['../classPatient.html#a82fa1f20987f1da67ee32a267b3e9c59',1,'Patient']]],
  ['robot_3',['robot',['../classRobot.html',1,'Robot'],['../classRobot.html#af1d62a40994cf7ea2cfbf5220b079aa2',1,'Robot::Robot()']]],
  ['robot_2ecpp_4',['Robot.cpp',['../Robot_8cpp.html',1,'']]],
  ['robot_2eh_5',['Robot.h',['../Robot_8h.html',1,'']]],
  ['robotmanagementmenu_6',['robotManagementMenu',['../main_8cpp.html#ad448663e45a2e200260f02b5b7a24a2a',1,'main.cpp']]],
  ['robots_7',['robots',['../classSistema.html#a1954be491a70ce4aae67f05185d9ece0',1,'Sistema']]],
  ['role_8',['role',['../classUser.html#ac066a219bd8d28680aefb90ecc8fc635',1,'User']]]
];
