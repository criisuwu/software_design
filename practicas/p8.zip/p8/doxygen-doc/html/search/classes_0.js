var searchData=
[
  ['admin_0',['Admin',['../classAdmin.html',1,'']]]
];
