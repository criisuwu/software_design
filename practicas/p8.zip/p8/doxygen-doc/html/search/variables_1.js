var searchData=
[
  ['currenttask_0',['currentTask',['../classRobot.html#a1987e6682d595575f1a3e65f2ab77f10',1,'Robot']]]
];
