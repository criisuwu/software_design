var searchData=
[
  ['lastactivity_0',['lastActivity',['../classRobot.html#a12facbf6a536b93080accf9dfefa891c',1,'Robot']]]
];
