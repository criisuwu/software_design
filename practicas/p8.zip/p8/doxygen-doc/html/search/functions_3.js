var searchData=
[
  ['emergencyassistance_0',['emergencyAssistance',['../classRobot.html#a4485940b8d53c61b79d3778d11813d49',1,'Robot']]],
  ['execsql_1',['execSQL',['../sql__exceptions_8cpp.html#ab788c670fca11767ec0f56f16eec56c4',1,'sql_exceptions.cpp']]]
];
