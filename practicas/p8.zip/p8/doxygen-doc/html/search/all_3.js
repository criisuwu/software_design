var searchData=
[
  ['email_0',['email',['../classUser.html#ac35b7c63228119cb91acdbd7ed32b8cb',1,'User']]],
  ['emergencyassistance_1',['emergencyAssistance',['../classRobot.html#a4485940b8d53c61b79d3778d11813d49',1,'Robot']]],
  ['exceptions_2eh_2',['exceptions.h',['../exceptions_8h.html',1,'']]],
  ['execsql_3',['execSQL',['../sql__exceptions_8cpp.html#ab788c670fca11767ec0f56f16eec56c4',1,'sql_exceptions.cpp']]]
];
