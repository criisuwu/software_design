var searchData=
[
  ['addnotestoappointment_0',['addNotesToAppointment',['../classDoctor.html#af964da62b97cdd21d7cac18674543c2f',1,'Doctor']]],
  ['admin_1',['Admin',['../classAdmin.html#a448554907972c73d9680155a00b3970d',1,'Admin']]],
  ['assignanyrobot_2',['assignAnyRobot',['../classSistema.html#a8f94144d7165754eaa871512469039ae',1,'Sistema']]],
  ['assignrobottask_3',['assignRobotTask',['../classSistema.html#ab441c045868f9835285de2ac160fa8af',1,'Sistema']]],
  ['assignschedule_4',['assignSchedule',['../classAdmin.html#a6fd079434d5bdc14a2c195e42687039e',1,'Admin']]],
  ['assignscheduletodoctor_5',['assignScheduleToDoctor',['../classSistema.html#a6c0b070e337e25c0a9f25d60570a7eeb',1,'Sistema']]],
  ['assigntask_6',['assignTask',['../classRobot.html#a189c43aa8112d86e426aa894311ea7b1',1,'Robot']]]
];
