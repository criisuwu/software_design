var searchData=
[
  ['specialty_0',['specialty',['../classDoctor.html#a0af6906851207d4d36aac959dd747d11',1,'Doctor']]],
  ['state_1',['state',['../classRobot.html#ad7e83b46946f0b8a78cf11f4666777bd',1,'Robot']]]
];
