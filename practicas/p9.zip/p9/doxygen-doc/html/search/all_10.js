var searchData=
[
  ['viewallusers_0',['viewAllUsers',['../classAdmin.html#addd504e4890e76dbb708188bde645f7c',1,'Admin']]],
  ['viewdoctorslist_1',['viewDoctorsList',['../classAdmin.html#a63c185a2aef72ab4e4e8c62abd06c971',1,'Admin']]],
  ['viewmyappointments_2',['viewMyAppointments',['../classPatient.html#a704e4dfb0a59474bf8832e7a02789c80',1,'Patient']]],
  ['viewmyschedule_3',['viewMySchedule',['../classDoctor.html#a694c23cd59b9b8f053734486cc4b5372',1,'Doctor']]]
];
