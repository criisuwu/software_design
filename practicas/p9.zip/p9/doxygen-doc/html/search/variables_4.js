var searchData=
[
  ['id_0',['id',['../classRobot.html#ad7fd8fd1721ae41eb67246b9b360e7a6',1,'Robot::id'],['../classUser.html#aa7e6e39b43020bbe9c3a196b3689b0f7',1,'User::id']]],
  ['instance_1',['instance',['../classSistema.html#ac2d77d45c73ac63c7f8120264965c8c8',1,'Sistema']]]
];
