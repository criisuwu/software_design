var searchData=
[
  ['lastactivity_0',['lastActivity',['../classRobot.html#a12facbf6a536b93080accf9dfefa891c',1,'Robot']]],
  ['loginuser_1',['loginuser',['../classSistema.html#a47d1acd84ef5cd60735f821f303d3c80',1,'Sistema::loginUser()'],['../main_8cpp.html#a16ba583341554f7a7286f4825794ec2b',1,'loginUser():&#160;main.cpp']]]
];
