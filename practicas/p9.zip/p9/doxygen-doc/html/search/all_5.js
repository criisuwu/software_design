var searchData=
[
  ['getallusers_0',['getAllUsers',['../classSistema.html#a10fad5f3abeee0871c9a4761468aa4a4',1,'Sistema']]],
  ['getdoctorslist_1',['getDoctorsList',['../classSistema.html#a9b25934d304fb47644608d6ca3128e00',1,'Sistema']]],
  ['getemail_2',['getEmail',['../classUser.html#a68c520e78268ba63c97ff04b6fb210a1',1,'User']]],
  ['getid_3',['getid',['../classRobot.html#a8d1d94c9cab78a96851785b1679cd457',1,'Robot::getId()'],['../classUser.html#a010077fcd52d32fd3b4e1171f748a86a',1,'User::getId()']]],
  ['getinstance_4',['getInstance',['../classSistema.html#ae6f4460ef7164a0c4b77b072e22c8db4',1,'Sistema']]],
  ['getlastactivity_5',['getLastActivity',['../classRobot.html#a52c52a8da9273bb48dde93a7eedc0788',1,'Robot']]],
  ['getname_6',['getName',['../classUser.html#a446a64e63adafbc2e1428532275ad6a1',1,'User']]],
  ['getpassword_7',['getPassword',['../classUser.html#a180e5acdc4b150463652d90d54caa8fc',1,'User']]],
  ['getrole_8',['getRole',['../classUser.html#a374cbe023e5cc08bdec6d7d009c4cfe4',1,'User']]],
  ['getspecialty_9',['getSpecialty',['../classDoctor.html#a8db27937fc7ea3afcff0666d2537dcdc',1,'Doctor']]],
  ['getstate_10',['getState',['../classRobot.html#a66c7966fb5f25bc654cbb29f33af0ae7',1,'Robot']]],
  ['gettelephone_11',['getTelephone',['../classPatient.html#aaf23dd34b89f8a72e09aaf34aa99b4c9',1,'Patient']]],
  ['getusername_12',['getUsername',['../classUser.html#a7079d6aefd9d1b930d837039c1b3e7df',1,'User']]],
  ['guidepatient_13',['guidePatient',['../classRobot.html#acc5c78240fedeed22d3f8b1371782257',1,'Robot']]]
];
