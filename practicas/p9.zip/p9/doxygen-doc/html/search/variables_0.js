var searchData=
[
  ['active_0',['active',['../classRobot.html#aa14a576c2af71d2dbe2fd22033086682',1,'Robot']]]
];
