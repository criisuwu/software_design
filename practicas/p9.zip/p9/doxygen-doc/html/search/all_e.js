var searchData=
[
  ['telephone_0',['telephone',['../classPatient.html#a3b13f4948931dbfba688cff60d48ff4e',1,'Patient']]]
];
