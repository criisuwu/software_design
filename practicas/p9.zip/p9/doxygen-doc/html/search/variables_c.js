var searchData=
[
  ['username_0',['username',['../classUser.html#aacbb807e514280f69e00bec7d71f3aee',1,'User']]]
];
