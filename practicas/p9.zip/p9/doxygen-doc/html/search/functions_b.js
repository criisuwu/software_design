var searchData=
[
  ['patient_0',['Patient',['../classPatient.html#a57f4bb407571c51aeea44416b6d3068c',1,'Patient']]]
];
