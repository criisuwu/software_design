var searchData=
[
  ['_7esistema_0',['~Sistema',['../classSistema.html#aafc86e0f2c3d734fb4c0985f70c27a1a',1,'Sistema']]],
  ['_7euser_1',['~User',['../classUser.html#a634d7ad22c3d2b5fed35f71e10d98628',1,'User']]]
];
