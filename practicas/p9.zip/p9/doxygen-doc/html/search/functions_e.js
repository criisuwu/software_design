var searchData=
[
  ['updatestate_0',['updateState',['../classRobot.html#a205956259148425074016369b258f13f',1,'Robot']]],
  ['user_1',['User',['../classUser.html#a6a08c3aa21e1eaed88b4d039d93e8341',1,'User']]]
];
