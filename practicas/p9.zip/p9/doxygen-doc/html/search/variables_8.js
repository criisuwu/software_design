var searchData=
[
  ['password_0',['password',['../classUser.html#ac2f2e75b15e8eb6cbb030fc85a6cd59f',1,'User']]],
  ['position_1',['position',['../classRobot.html#a5004831653b996fced2f429940a0d704',1,'Robot']]]
];
