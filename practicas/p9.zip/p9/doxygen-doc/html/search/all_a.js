var searchData=
[
  ['opendatabase_0',['openDatabase',['../sql__exceptions_8cpp.html#aff9feb94de9f2d5e2944ba58d4d072cb',1,'sql_exceptions.cpp']]]
];
