var searchData=
[
  ['name_0',['name',['../classUser.html#a085d8d69282b6298964eab8351584536',1,'User']]]
];
