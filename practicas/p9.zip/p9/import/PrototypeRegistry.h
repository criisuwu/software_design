#ifndef PROTOTYPE_REGISTRY_H
#define PROTOTYPE_REGISTRY_H

#include <map>
#include <string>
#include <memory>
#include "User.h"

/**
 * @class PrototypeRegistry
 * @brief Registro de prototipos para el patrón Prototype
 * 
 * Mantiene una instancia prototipo de cada tipo de usuario
 * y permite clonarlas cuando sea necesario
 */
class PrototypeRegistry {
private:
    // Mapa que almacena prototipos por rol
    std::map<std::string, User*> prototypes;
    
    // Singleton
    static PrototypeRegistry* instance;
    
    // Constructor privado
    PrototypeRegistry();
    
    // Prohibir copia y asignación
    PrototypeRegistry(const PrototypeRegistry&) = delete;
    PrototypeRegistry& operator=(const PrototypeRegistry&) = delete;

public:
    /**
     * @brief Destructor - libera los prototipos
     */
    ~PrototypeRegistry();
    
    /**
     * @brief Obtiene la instancia única del registro
     */
    static PrototypeRegistry& getInstance() {
        if (!instance) {
            instance = new PrototypeRegistry();
        }
        return *instance;
    }
    
    /**
     * @brief Registra un prototipo para un rol específico
     * @param role Rol del usuario (Doctor, Patient, Administrator)
     * @param prototype Puntero al prototipo a registrar
     */
    void registerPrototype(const std::string& role, User* prototype);
    
    /**
     * @brief Obtiene un clon del prototipo para el rol especificado
     * @param role Rol del usuario
     * @return Puntero al usuario clonado, o nullptr si no existe el prototipo
     */
    User* getPrototype(const std::string& role) const;
    
    /**
     * @brief Inicializa los prototipos predeterminados
     */
    void initializePrototypes();
};

#endif // PROTOTYPE_REGISTRY_H