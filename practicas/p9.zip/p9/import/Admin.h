#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"
#include <iostream>
#include <string>
#include <map>

// Forward declaration
class Command;
class Sistema;

class Admin : public User {
private:
    // Mapa de comandos: mapea opciones del menú a comandos
    std::map<int, Command*> commands;

public:
    Admin(int id = 0, const std::string& username = "", const std::string& password = "", 
          const std::string& name = "", const std::string& email = "");
    
    // Constructor de copia para el patrón Prototype
    Admin(const Admin& other);
    
    // Destructor para liberar comandos
    ~Admin();
    
    void showMenu() override;
    void displayInfo() const override;
    
    // Implementación del patrón Prototype
    User* clone() const override {
        return new Admin(*this);
    }
    
    // Configuración de comandos (patrón Command)
    void setupCommands(Sistema* system);
    
    // Ejecutar comando según opción
    void executeCommand(int option);
    
    // Limpiar comandos
    void clearCommands();
};

#endif