#ifndef PATIENT_H
#define PATIENT_H

#include "User.h"
#include <iostream>
#include <string>

class Patient : public User {
private:
    std::string telephone;

public:
    Patient(int id = 0, const std::string& username = "", const std::string& password = "", 
            const std::string& name = "", const std::string& email = "", const std::string& telephone = "");
    
    // Constructor de copia para el patrón Prototype
    Patient(const Patient& other) 
        : User(other), telephone(other.telephone) {}
    
    std::string getTelephone() const { return telephone; }
    void setTelephone(const std::string& tel) { telephone = tel; }
    
    void showMenu() override;
    void displayInfo() const override;
    
    // Implementación del patrón Prototype
    User* clone() const override {
        return new Patient(*this);
    }
    
    // Funcionalidades específicas
    void requestAppointment();
    void viewMyAppointments();
    void cancelAppointment();
};

#endif