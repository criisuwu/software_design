#ifndef CONCRETE_COMMANDS_H
#define CONCRETE_COMMANDS_H

#include "Command.h"
#include "Sistema.h"

/**
 * @class ViewDoctorsCommand
 * @brief Comando para ver la lista de doctores
 */
class ViewDoctorsCommand : public Command {
public:
    ViewDoctorsCommand(Sistema* sys) : Command(sys) {}
    
    void execute() override;
};

/**
 * @class CreateDoctorCommand
 * @brief Comando para crear un nuevo doctor
 */
class CreateDoctorCommand : public Command {
public:
    CreateDoctorCommand(Sistema* sys) : Command(sys) {}
    
    void execute() override;
};

/**
 * @class AssignScheduleCommand
 * @brief Comando para asignar agenda a un doctor
 */
class AssignScheduleCommand : public Command {
public:
    AssignScheduleCommand(Sistema* sys) : Command(sys) {}
    
    void execute() override;
};

/**
 * @class ViewAllUsersCommand
 * @brief Comando para ver todos los usuarios
 */
class ViewAllUsersCommand : public Command {
public:
    ViewAllUsersCommand(Sistema* sys) : Command(sys) {}
    
    void execute() override;
};

#endif // CONCRETE_COMMANDS_H