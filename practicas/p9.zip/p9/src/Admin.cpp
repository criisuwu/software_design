#include "../import/Admin.h"
#include "../import/Command.h"
#include "../import/ConcreteCommands.h"
#include "../import/Sistema.h"
#include <iostream>

Admin::Admin(int id, const std::string& username, const std::string& password, 
             const std::string& name, const std::string& email)
    : User(id, username, password, "Administrator", name, email) {}

Admin::Admin(const Admin& other) : User(other) {
    // No copiamos los comandos, se configurarán cuando sea necesario
}

Admin::~Admin() {
    clearCommands();
}

void Admin::setupCommands(Sistema* system) {
    clearCommands();
    
    // Crear y registrar comandos
    commands[1] = new CreateDoctorCommand(system);
    commands[2] = new AssignScheduleCommand(system);
    commands[3] = new ViewDoctorsCommand(system);
    commands[4] = new ViewAllUsersCommand(system);
}

void Admin::executeCommand(int option) {
    auto it = commands.find(option);
    if (it != commands.end()) {
        it->second->execute();
    }
}

void Admin::clearCommands() {
    for (auto& pair : commands) {
        delete pair.second;
    }
    commands.clear();
}

void Admin::showMenu() {
    // Configurar comandos con la instancia Singleton de Sistema
    setupCommands(&Sistema::getInstance());
    
    int option;
    do {
        std::cout << "\n=== MENÚ ADMINISTRADOR ===\n";
        std::cout << "1. Crear Doctor\n";
        std::cout << "2. Asignar Agenda a Doctor\n";
        std::cout << "3. Ver Lista de Doctores\n";
        std::cout << "4. Ver Todos los Usuarios\n";
        std::cout << "5. Ver Mi Información\n";
        std::cout << "6. Cerrar Sesión\n";
        std::cout << "Seleccione una opción: ";
        std::cin >> option;
        
        if (option >= 1 && option <= 4) {
            // Usar patrón Command
            executeCommand(option);
        } else if (option == 5) {
            displayInfo();
        } else if (option == 6) {
            std::cout << "Cerrando sesión...\n";
        } else {
            std::cout << "Opción no válida\n";
        }
    } while(option != 6);
    
    clearCommands();
}

void Admin::displayInfo() const {
    std::cout << "\n=== INFORMACIÓN DEL ADMINISTRADOR ===\n";
    User::displayInfo();
}