#include "../import/ConcreteCommands.h"
#include <iostream>

void ViewDoctorsCommand::execute() {
    std::cout << "\n--- Lista de Doctores ---\n";
    auto doctors = system->getDoctorsList();
    
    if (doctors.empty()) {
        std::cout << "No hay doctores registrados.\n";
        return;
    }
    
    for (const auto& d : doctors) {
        std::cout << "\nID: " << d->getId()
                  << "\nNombre: " << d->getName()
                  << "\n-----------------------\n";
    }
}

void CreateDoctorCommand::execute() {
    std::cout << "\n--- Crear Doctor ---\n";

    std::string username, password, name, email, specialty, telephone;

    std::cout << "Usuario: ";
    std::cin >> username;
    std::cout << "Contraseña: ";
    std::cin >> password;
    std::cout << "Nombre: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "Correo: ";
    std::cin >> email;
    std::cout << "Especialidad: ";
    std::cin.ignore();
    std::getline(std::cin, specialty);
    std::cout << "Teléfono: ";
    std::cin >> telephone;

    bool ok = system->registerUser(username, password, "Doctor",
                                   name, email, specialty, telephone);

    if (ok)
        std::cout << "Doctor creado exitosamente.\n";
    else
        std::cout << "Error al crear doctor.\n";
}

void AssignScheduleCommand::execute() {
    std::cout << "\n--- Asignar Agenda a Doctor ---\n";

    int idDoctor;
    std::string day, start, end;

    std::cout << "ID del Doctor: ";
    std::cin >> idDoctor;
    std::cout << "Día (Ej: Lunes): ";
    std::cin >> day;
    std::cout << "Hora inicio (HH:MM): ";
    std::cin >> start;
    std::cout << "Hora fin (HH:MM): ";
    std::cin >> end;

    bool ok = system->assignScheduleToDoctor(idDoctor, day, start, end);

    if (ok)
        std::cout << "Agenda asignada correctamente.\n";
    else
        std::cout << "Error asignando agenda.\n";
}

void ViewAllUsersCommand::execute() {
    std::cout << "\n--- Todos los Usuarios ---\n";
    
    auto users = system->getAllUsers();

    if (users.empty()) {
        std::cout << "No hay usuarios registrados.\n";
        return;
    }

    for (const auto& u : users) {
        std::cout << "\nID: " << u->getId()
                  << "\nUsuario: " << u->getUsername()
                  << "\nRol: " << u->getRole()
                  << "\nNombre: " << u->getName()
                  << "\nEmail: " << u->getEmail()
                  << "\n------------------------\n";
    }
}