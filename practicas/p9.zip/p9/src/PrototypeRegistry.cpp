#include "../import/PrototypeRegistry.h"
#include "../import/Doctor.h"
#include "../import/Patient.h"
#include "../import/Admin.h"
#include <iostream>

// Inicializar el puntero estático
PrototypeRegistry* PrototypeRegistry::instance = nullptr;

PrototypeRegistry::PrototypeRegistry() {
    initializePrototypes();
}

PrototypeRegistry::~PrototypeRegistry() {
    // Liberar todos los prototipos
    for (auto& pair : prototypes) {
        delete pair.second;
    }
    prototypes.clear();
}

void PrototypeRegistry::registerPrototype(const std::string& role, User* prototype) {
    // Si ya existe un prototipo para este rol, liberarlo
    auto it = prototypes.find(role);
    if (it != prototypes.end()) {
        delete it->second;
    }
    
    prototypes[role] = prototype;
}

User* PrototypeRegistry::getPrototype(const std::string& role) const {
    auto it = prototypes.find(role);
    if (it != prototypes.end()) {
        // Clonar el prototipo
        return it->second->clone();
    }
    return nullptr;
}

void PrototypeRegistry::initializePrototypes() {
    // Crear prototipos vacíos para cada tipo de usuario
    // Estos serán clonados y luego se llenarán con datos de la BD
    
    Doctor* doctorPrototype = new Doctor();
    Patient* patientPrototype = new Patient();
    Admin* adminPrototype = new Admin();
    
    registerPrototype("Doctor", doctorPrototype);
    registerPrototype("Patient", patientPrototype);
    registerPrototype("Administrator", adminPrototype);
    
    std::cout << "[PrototypeRegistry] Prototipos inicializados.\n";
}